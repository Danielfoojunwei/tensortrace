"""TG-Tinker integration tests."""
