"""E2E tests for TG-Tinker training and inference."""
